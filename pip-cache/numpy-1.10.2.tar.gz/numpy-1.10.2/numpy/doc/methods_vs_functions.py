"""

=====================
Methods vs. Functions
=====================

Placeholder for Methods vs. Functions documentation.

"""
from __future__ import division, absolute_import, print_function
