Flask-Testing
-------------

Flask unittest integration.

Links
`````

* `documentation <http://packages.python.org/Flask-Testing>`
* `development version <http://github.com/jarus/flask-testing/zipball/master#egg=Flask-Testing-dev>`



